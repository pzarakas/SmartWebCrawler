# Kensington

## Description

Kensington is a modified open-source File Transfer Protocol (FTP) server for Node.js.

It supports anonymous and authenticated users. 

Anonymous users (identified with
the username "anonymous" and any password) are only allowed
to write files in `/data/ftproot/_anonymous/`, and are not allowed to retrieve
files.

Non-anonymous users are authenticated against the SQLite3 database
`/data/kensington.sqlite3`, and are allowed to read, write, and rename
files in
`/data/ftproot/`, including the `_anonymous_` directory.

### Scope for Analysis

This is an FTP server. Anonymous and authenticated access are supported.

This service uses a SQLite3 database to store user information. The structure
of this database is guaranteed (see the "Persistent Data" section below),
but the content may vary. Proofs-of-Vulnerability (PoVs) 
MAY depend on the `users` table existing. PoVs MUST NOT depend on
specific content in the `users` table.
PoVs MUST NOT depend on the
existence or content of a `users_cheatsheet` table. The `users_cheatsheet` is
only used by the poller, and the challenge attempts to delete this table on startup.

### Running It

Kensington is a JavaScript application. It can be run as-is:

```
guest> node ./bin/index.js
```

### Persistent Data

This challenge depends on successful reads and writes to the `/data` directory.
The poller operates on its own `/data` directory, that is expected to stay
synchronized with the challenge `/data`.
An initial load from `/base_data` is required for both the challenge and 
poller.

FTP content is stored in `/data/ftproot/`. Normal poller operation will add
files to subdirectories here, but the filenames are timestamped and random,
and shouldn't conflict over multiple poller runs
[assuming the poller experiences linear time.][time]

The `users_cheatsheet` table will be deleted during the challenge
launch; the poller needs plaintext passwords, but the challenge does not, and
they're not in scope for proofs-of-vulnerability.
