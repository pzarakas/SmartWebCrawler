CREATE TABLE users_cheatsheet (
  id integer PRIMARY KEY,
  name varchar,
  password varchar NOT NULL
);
