# Crawler Extension
This is a Chrome extension used to crawl a random subset of links within a domain, to explore tainted data flows for web security
